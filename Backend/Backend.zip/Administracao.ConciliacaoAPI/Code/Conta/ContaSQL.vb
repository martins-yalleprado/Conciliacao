Namespace Code.Conta
  Public Class ContaSQL
    Public Function SelectConta() As String
      Dim stringBuilder As New StringBuilder()
      stringBuilder.Append("  ")
      Return stringBuilder.ToString()
    End Function
    Public Function AtivarConta() As String
      Dim stringBuilder As New StringBuilder()
      stringBuilder.Append("  ")
      Return stringBuilder.ToString()
    End Function
    Public Function InativarConta() As String
      Dim stringBuilder As New StringBuilder()
      stringBuilder.Append(" ")
      Return stringBuilder.ToString()
    End Function
    Public Function InsertConta() As String
      Dim stringBuilder As New StringBuilder()
      stringBuilder.Append("  ")
      Return stringBuilder.ToString()
    End Function
  End Class
End Namespace
