Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Namespace Code.Grupo
	Public Class GrupoBLL
	End Class
End Namespace
