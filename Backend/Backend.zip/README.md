# VBNetWebAPI
VB.Net WebAPI Owin Token Based Authentication
